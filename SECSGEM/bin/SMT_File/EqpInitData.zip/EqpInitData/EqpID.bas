Attribute VB_Name = "EqpID"
' Event ID 
Public Const EQP_EVENT_1 = 100               ' UINT_4    Eqp1Event
Public Const EQP_EVENT_2 = 101               ' UINT_4    Eqp2Event
Public Const EQP_EVENT_3 = 102               ' UINT_4    Eqp3Event
Public Const EQP_EVENT_4 = 103               ' UINT_4    Eqp4Event
Public Const EQP_EVENT_5 = 104               ' UINT_4    Eqp5Event
Public Const EQP_EVENT_6 = 105               ' UINT_4    Eqp6Event

' SV ID 
Public Const SV_BOOLEAN = 2001               ' BOOLEAN   BooleanTypeStatus
Public Const SV_CONTROL_JOB_NAME = 2002      ' ASCII     ControlJobName
Public Const SV_INMP1_NOW_TEMP = 2003        ' FT_4      INMP1NowTemp
Public Const SV_BINARY = 2004                ' BINARY    BinaryTypeStatus
Public Const LIST_SV1 = 3001                 ' LIST      WaferMappingList
Public Const LIST_SV2 = 3002                 ' LIST      WaferStatusList
Public Const SV_EQP_STSTUS = 100001          ' UINT_1    EquipmentStatus
Public Const SV_UINT_4 = 100002              ' UINT_4    UINT_4typeStatus

' DV ID 
Public Const DV_8100 = 8100                  ' FT_4      DVID_8100
Public Const DV_8101 = 8101                  ' UINT_1    DVID_8101
Public Const DV_8102 = 8102                  ' UINT_2    DVID_8102
Public Const DV_8103 = 8103                  ' UINT_4    DVID_8103
Public Const DV_8104 = 8104                  ' FT_4      DVID_8104
Public Const DV_8105 = 8105                  ' INT_1     DVID_8105
Public Const DV_8106 = 8106                  ' INT_2     DVID_8106
Public Const DV_8107 = 8107                  ' INT_4     DVID_8107
Public Const DV_8108 = 8108                  ' ASCII     DVID_8108
Public Const DV_8109 = 8109                  ' BOOLEAN   DVID_8109

' EConst ID 
Public Const EC1_UINT_1 = 1001               ' UINT_1    EC1def
Public Const EC2_UINT_2 = 1002               ' UINT_2    EC2def
Public Const EC3_FT_4 = 1003                 ' FT_4      EC3def
Public Const EC4_FT_8 = 1004                 ' FT_8      EC4def
Public Const EC5_UINT_4 = 1005               ' UINT_4    EC5def
Public Const EC6_INT_1 = 1006                ' INT_1     EC6def
Public Const EC7_INT_2 = 1007                ' INT_2     EC7def
Public Const EC8_INT_4 = 1008                ' INT_4     EC8def
Public Const EC9_BINARY = 1009               ' BINARY    EC9def
Public Const EC10_BOOLEAN = 1010             ' BOOLEAN   EC10def
Public Const EC11_ASCII = 1011               ' ASCII     EC11def

' Alarm ID 
Public Const ALARM_PUMP_PRESS = 9001         ' UINT_4    ���O���`PumpPressFressl
Public Const ALARM_EM = 9002                 ' UINT_4    EFEM��氱��}�����UEmergencyStoppressed
Public Const ALARM_HEATER_FAIL = 9003        ' UINT_4    �[��������HeaterFail
Public Const ALARM_HEATER_FAIL2 = 1000001    ' UINT_4    �[
