﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace TrimGap
{
    public partial class SignalAnalysisForm : Form
    {
        private bool plotflag = false;
        private int Wafertype = 2;
        private double W1 = 0, W2 = 0;
        private string errormsg = "";
        private bool SignalPlotFlag = false;
        private string _filename = "";
        private Bitmap img;
        private int imgW, imgH, point;
        private byte[] imgData;

        public SignalAnalysisForm()
        {
            if (sram.UserAuthority == permissionEnum.ad)
            {
                plotflag = true;
            }
            else
            {
                plotflag = false;
            }
            InitializeComponent();
            Init_chartSignal();
            cb_WaferType.SelectedIndex = 0;
            if (!bWSignalPlot.IsBusy)
            {
                bWSignalPlot.RunWorkerAsync();
            }
        }

        private void Init_chartSignal()
        {
            // 每次使用此function前先清除圖表
            chartSignal.Series[0].Points.Clear();//清除圖表
            chartSignal.Series[1].Points.Clear();//清除圖表
            chartSignal.Series[2].Points.Clear();//清除圖表
            chartSignal.Series[3].Points.Clear();//清除圖表
            chartSignal.Series[4].Points.Clear();//清除圖表
            chartSignal.Series[5].Points.Clear();//清除圖表
            chartSignal.Series[6].Points.Clear();//清除圖表
            chartSignal.Series[7].Points.Clear();//清除圖表

            chartSignal.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray; //背景網格顏色
            chartSignal.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray; //背景網格顏色

            chartSignal.ChartAreas[0].AxisX.Title = "um";
            chartSignal.ChartAreas[0].AxisX.TitleFont = new Font(chartSignal.ChartAreas[0].AxisX.Name, 22);

            //chartSensor.ChartAreas[0].CursorX.IsUserEnabled = true;
            //chartSensor.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            //chartSensor.ChartAreas[0].CursorX.Interval = 0;
            //chartSensor.ChartAreas[0].CursorX.IntervalOffset = 0;
            //chartSensor.ChartAreas[0].AxisX.ScaleView.Zoomable = true;           //啟用縮放視圖
            //chartSensor.ChartAreas[0].AxisX.ScrollBar.BackColor = Color.RosyBrown;
            //chartSensor.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            //chartSensor.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.White;
            //chartSensor.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.All;//啟用X軸滾動條按鈕

            chartSignal.ChartAreas[0].AxisY.Title = "um";
            chartSignal.ChartAreas[0].AxisY.TitleFont = new Font(chartSignal.ChartAreas[0].AxisY.Name, 22);
            chartSignal.ChartAreas[0].AxisY.TitleAlignment = StringAlignment.Far;    //設定title位置
            chartSignal.ChartAreas[0].AxisY.TextOrientation = TextOrientation.Rotated270; //設定title文字方向
            chartSignal.ChartAreas[0].AxisY.LabelStyle.ForeColor = Color.Blue;       //設定軸顏色

            chartSignal.ChartAreas[0].CursorX.IsUserEnabled = true;
            chartSignal.ChartAreas[0].CursorX.AutoScroll = true;
            chartSignal.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chartSignal.ChartAreas[0].CursorX.SelectionColor = System.Drawing.SystemColors.Highlight;
            chartSignal.ChartAreas[0].CursorY.IsUserEnabled = true;
            chartSignal.ChartAreas[0].CursorY.AutoScroll = true;
            chartSignal.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;
            chartSignal.ChartAreas[0].CursorY.SelectionColor = System.Drawing.SystemColors.Highlight;

            //chartSensor.ChartAreas[0].AxisY.ScrollBar.IsPositionedInside = true;
            //chartSensor.ChartAreas[0].AxisY.ScrollBar.Enabled = true;
            //chartSensor.ChartAreas[0].AxisY.ScaleView.Zoomable = true;
            //chartSensor.ChartAreas[0].AxisY.ScrollBar.ButtonStyle = ScrollBarButtonStyles.All;
            //chartSensor.ChartAreas[0].CursorY.IsUserEnabled = true;
            //chartSensor.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;
            //chartSensor.ChartAreas[0].CursorY.Interval = 0;
            //chartSensor.ChartAreas[0].CursorY.IntervalOffset = 0;

            //chartSignal.ChartAreas[0].AxisY2.Title = "%";
            //chartSignal.ChartAreas[0].AxisY2.TitleFont = new Font(chartSignal.ChartAreas[0].AxisY2.Name, 14);
            //chartSignal.ChartAreas[0].AxisY2.TitleAlignment = StringAlignment.Far;
            //chartSignal.ChartAreas[0].AxisY2.TextOrientation = TextOrientation.Horizontal;
            //chartSignal.ChartAreas[0].AxisY2.LabelStyle.ForeColor = Color.Red;      //設定線條顏色

            // distance
            // ---------------------
            chartSignal.Series[0].Color = Color.Blue;                 //設定線條顏色
            chartSignal.Series[0].ToolTip = "#VALX,#VALY";            //鼠標停留在數據上，顯示XY值
            chartSignal.Series[0].ChartType = SeriesChartType.FastLine;   //設定線條種類 折線圖 fastline不能用marker
            chartSignal.Series[0].YAxisType = AxisType.Primary;           //主坐標軸
            chartSignal.Series[0].MarkerStyle = MarkerStyle.None;
            chartSignal.Series[1].ToolTip = "#VALX,#VALY";            //鼠標停留在數據上，顯示XY值
            chartSignal.Series[1].ChartType = SeriesChartType.FastLine;   //設定線條種類 折線圖
            chartSignal.Series[1].YAxisType = AxisType.Primary;           //主坐標軸
            chartSignal.Series[1].Color = System.Drawing.Color.Red;                 //設定線條顏色
            chartSignal.ChartAreas[0].AxisX.Maximum = 7000;  //設定X軸最大值 預設為10000
            chartSignal.ChartAreas[0].AxisX.Minimum = 0;     //設定X軸最小值
            chartSignal.ChartAreas[0].AxisX.Interval = 500; //設定X軸間隔 最大值/10

            chartSignal.ChartAreas[0].AxisY.Maximum = 100;  //設定Y軸最大值
            chartSignal.ChartAreas[0].AxisY.Minimum = -70;     //設定Y軸最小值
            chartSignal.ChartAreas[0].AxisY.Interval = 10; //設定Y軸間隔 最大值/10

            chartSignal.ChartAreas[0].AxisY.ScrollBar.IsPositionedInside = true;
            chartSignal.ChartAreas[0].AxisY.ScrollBar.Enabled = true;

            chartSignal.Series[0].Points.AddXY(0, 0);
            chartSignal.Series[1].Points.AddXY(0, 0);
            //this.chartSignal.Series.Add(series3);//將線畫在圖上
        }

        private void btnSignalAnalysis_Click(object sender, EventArgs e)
        {
            if (!Flag.SensorAnalysisFlag) // 分析中 或是Stage在席On 不給分析
            {
                progressBar_SignalAnalysis.Value = 0;
                //MessageBox.Show("請點選.txt檔案");
                //Console.WriteLine("D:\\FTGM1\\DataDirectory\\" + DateTime.Now.Year.ToString() + "\\");
                if (Directory.Exists("D:\\FTGM1\\DataDirectory\\" + DateTime.Now.Year.ToString() + "\\"))
                {
                    openFileDialog1.InitialDirectory = "D:\\FTGM1\\DataDirectory\\" + DateTime.Now.Year.ToString() + "\\";
                }
                else
                {
                    openFileDialog1.InitialDirectory = "D:\\FTGM1\\DataDirectory\\";
                }
                openFileDialog1.FileName = "請選擇日期及分析檔案名稱";
                /*if (Wafertype == 0)
                {
                    openFileDialog1.Filter = "png files (*.png)|*.txt|All files (*.*)|*.*";
                }
                else
                {
                    openFileDialog1.Filter = "csv files (*.csv)|*.txt|All files (*.*)|*.*";
                }*/

                try
                {
                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        //string[] names = openFileDialog1.FileNames;

                        ///
                        Init_chartSignal();
                        //StreamReader readline = new StreamReader(@"C:\Users\user\Desktop\ttt.txt");
                        string openFile = openFileDialog1.FileName;//儲存路徑
                        System.IO.FileInfo openName = new FileInfo(openFileDialog1.FileName);//取得完整檔名(含副檔名)
                        string Name = openName.Name.Substring(0, openName.Name.Length - 4);//取得檔名

                        if (Wafertype == 0)
                        {
                            img = new Bitmap(openFileDialog1.FileName);
                            PixelFormat a = img.PixelFormat;
                            imgW = img.Width;
                            imgH = img.Height;
                            point = imgW / 2;
                            BitmapData bd = img.LockBits(new Rectangle(0, 0, imgW, imgH), ImageLockMode.ReadWrite, a);
                            IntPtr intPtr = bd.Scan0;
                            imgData = new byte[imgW * imgH];
                            Marshal.Copy(intPtr, imgData, 0, imgW * imgH);
                            img.UnlockBits(bd);
                            //MemoryStream ms = new MemoryStream();
                            //img.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp,);
                            //imgData = ms.GetBuffer();
                            //ImageConverter converter = new ImageConverter();
                            //imgData = (byte[])converter.ConvertTo(img, typeof(byte[]));
                            pB_BlueTape.Image = img;
                            pB_BlueTape.Image.RotateFlip(RotateFlipType.Rotate270FlipNone);
                            pB_BlueTape.Refresh();
                        }
                        else
                        {
                            StreamReader read = new StreamReader(openFileDialog1.FileName);

                            string ReadAll;
                            string[] ReadArray1;//, ReadArray2;
                            ReadAll = read.ReadToEnd(); // 一次讀全部
                            ReadArray1 = Regex.Split(ReadAll, "\r\n", RegexOptions.IgnoreCase);
                            double[] array2 = new double[ReadArray1.Length - 1];
                            for (int i = 0; i < ReadArray1.Length - 1; i++)
                            {
                                array2[i] = Convert.ToSingle(ReadArray1[i]);
                            }
                            progressBar_SignalAnalysis.Value = 10;
                            SignalPlotData.rawData = array2;
                            read.Close();
                        }

                        InsertLog.SavetoDB(4, "分析檔案: " + Name);
                        lb_analysisFileName.Text = Name;
                        _filename = Name;
                        SignalPlotFlag = true;
                    }
                }
                catch (Exception ee)
                {
                    Console.WriteLine(ee.Message);
                    MessageBox.Show("資料選取錯誤");
                }
            }
            else
            {
                MessageBox.Show("自動模式資料分析中，請等待分析結束再操作。");
            }
        }

        private void bWSignalPlot_DoWork(object sender, DoWorkEventArgs e)
        {
            bWSignalPlot.WorkerReportsProgress = true;
            while (true)
            {
                try
                {
                    SpinWait.SpinUntil(() => false, 100);
                    if (SignalPlotFlag)
                    {
                        if (Wafertype == 0)
                        {
                            Common.TrimGapAnalysis.CalculateBlueTape(imgData, imgW, imgH, 1000, false, fram.Analysis.BlueTapeThreshold, true, out SignalPlotData.resultdata);
                        }
                        else if (Wafertype == 1)
                        {
                            for (int i = 0; i < SignalPlotData.rawData.Length; i++)
                            {
                                SignalPlotData.rawData[i] = SignalPlotData.rawData[i] * AnalysisData.um2mm * fram.Analysis.Coefficient;
                            }
                            SignalPlotData.removezeroData = Common.TrimGapAnalysis.removeZero2(SignalPlotData.rawData);
                            Console.WriteLine("Analysis start:" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString());
                            Common.TrimGapAnalysis.tilting(plotflag, SignalPlotData.removezeroData, AnalysisData.Interval_X, out SignalPlotData.tiltingdata_x, out SignalPlotData.tiltingdata_y);
                            Common.TrimGapAnalysis.CalculateGap(plotflag, SignalPlotData.tiltingdata_x, SignalPlotData.tiltingdata_y, AnalysisData.Interval_X, Wafertype, fram.Analysis.Step1_Range_step1x0, fram.Analysis.Step1_Range_step1x1, 0, 0, fram.Analysis.Range1_Percent, fram.Analysis.Range2_Percent, out SignalPlotData.resultdata);
                            Console.WriteLine("Analysis Finish:" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString());
                        }
                        else if (Wafertype == 2)
                        {
                            for (int i = 0; i < SignalPlotData.rawData.Length; i++)
                            {
                                SignalPlotData.rawData[i] = SignalPlotData.rawData[i] * AnalysisData.um2mm * fram.Analysis.Coefficient;
                            }
                            SignalPlotData.removezeroData = Common.TrimGapAnalysis.removeZero2(SignalPlotData.rawData);
                            Console.WriteLine("Analysis start:" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString());
                            Common.TrimGapAnalysis.tilting(plotflag, SignalPlotData.removezeroData, AnalysisData.Interval_X, out SignalPlotData.tiltingdata_x, out SignalPlotData.tiltingdata_y);
                            Common.TrimGapAnalysis.CalculateGap(plotflag, SignalPlotData.tiltingdata_x, SignalPlotData.tiltingdata_y, AnalysisData.Interval_X, Wafertype, fram.Analysis.Step2_Range_step1x0, fram.Analysis.Step2_Range_step1x1, fram.Analysis.Step2_Range_step2x0, fram.Analysis.Step2_Range_step2x1, fram.Analysis.Range1_Percent, fram.Analysis.Range2_Percent, out SignalPlotData.resultdata);
                            Console.WriteLine("Analysis Finish:" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString());
                        }

                        SignalPlotFlag = false;
                        bWSignalPlot.ReportProgress(0);
                    }
                    else
                    {
                    }
                }
                catch (Exception ee)
                {
                    SignalPlotFlag = false;
                    bWSignalPlot.ReportProgress(10);
                    errormsg = ee.Message;
                    Console.WriteLine(ee.Message);
                    throw;
                }
            }
        }

        private void bWSignalPlot_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage == 0)
            {
                try
                {
                    //

                    #region showtextbox

                    if (Wafertype == 0)
                    {
                        tb_result_0.Text = "0";
                        tb_result_1.Text = "0";
                        tb_result_2.Text = SignalPlotData.resultdata[0].ToString("f2") + fram.Analysis.OffsetBlueTapeW;
                        tb_result_3.Text = "0";

                        List<double> xData = new List<double>();
                        for (int i = 0; i < imgH; i++)
                        {
                            xData.Add(i * 1.2);
                        }

                        List<int> yData = new List<int>();
                        for (int i = 0; i < imgH; i++)
                        {
                            yData.Add(imgData[imgW * i + point]);
                        }
                        chart1.Series[0].Points.DataBindXY(xData, yData);
                    }
                    else
                    {
                        #region Plot

                        chartSignal.ChartAreas[0].AxisY.Minimum = -10;

                        if (SignalPlotData.removezeroData.Max() + Math.Abs(SignalPlotData.removezeroData.Min()) > SignalPlotData.tiltingdata_y.Max())
                        {
                            if (SignalPlotData.removezeroData.Max() / 10 < 10)
                            {
                                chartSignal.ChartAreas[0].AxisY.Maximum = ((int)((SignalPlotData.removezeroData.Max() + Math.Abs(SignalPlotData.removezeroData.Min())) / 10) + 1) * 10;
                            }
                            else
                            {
                                chartSignal.ChartAreas[0].AxisY.Maximum = ((int)((SignalPlotData.removezeroData.Max() + Math.Abs(SignalPlotData.removezeroData.Min())) / 100) + 1) * 100;
                            }
                        }
                        else
                        {
                            if (SignalPlotData.tiltingdata_y.Max() / 10 < 10)
                            {
                                chartSignal.ChartAreas[0].AxisY.Maximum = ((int)(SignalPlotData.tiltingdata_y.Max() / 10) + 1) * 10;
                            }
                            else
                            {
                                chartSignal.ChartAreas[0].AxisY.Maximum = ((int)(SignalPlotData.tiltingdata_y.Max() / 100) + 1) * 100;
                            }
                        }

                        if (chartSignal.ChartAreas[0].AxisY.Maximum - chartSignal.ChartAreas[0].AxisY.Minimum > 100)
                        {
                            chartSignal.ChartAreas[0].AxisY.Interval = 100; //設定Y軸間隔 最大值/10
                        }
                        else
                        {
                            chartSignal.ChartAreas[0].AxisY.Interval = 10; //設定Y軸間隔 最大值/10
                        }

                        for (int i = 0; i < SignalPlotData.tiltingdata_y.Length; i++)
                        {
                            chartSignal.Series[0].Points.AddXY(SignalPlotData.tiltingdata_x[i], SignalPlotData.removezeroData[i] - SignalPlotData.removezeroData.Min());
                            chartSignal.Series[1].Points.AddXY(SignalPlotData.tiltingdata_x[i], SignalPlotData.tiltingdata_y[i]);
                        }
                        //
                        if (Wafertype == 1)
                        {
                            chartSignal.Series[2].Points.AddXY(0, SignalPlotData.resultdata[6]);
                            chartSignal.Series[2].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[6]);
                            chartSignal.Series[3].Points.AddXY(0, SignalPlotData.resultdata[7]);
                            chartSignal.Series[3].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[7]);
                            //chartSignal.Series[4].Points.AddXY(0, SignalPlotData.resultdata[8]);
                            //chartSignal.Series[4].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[8]);
                            chartSignal.Series[5].Points.AddXY(SignalPlotData.resultdata[9], 0);
                            chartSignal.Series[5].Points.AddXY(SignalPlotData.resultdata[9], SignalPlotData.tiltingdata_y.Max());
                            chartSignal.Series[6].Points.AddXY(SignalPlotData.resultdata[10], 0);
                            chartSignal.Series[6].Points.AddXY(SignalPlotData.resultdata[10], SignalPlotData.tiltingdata_y.Max());
                            //chartSignal.Series[7].Points.AddXY(SignalPlotData.resultdata[11], 0);
                            //chartSignal.Series[7].Points.AddXY(SignalPlotData.resultdata[11], SignalPlotData.tiltingdata_y.Min());
                        }
                        else if (Wafertype == 2)
                        {
                            chartSignal.Series[2].Points.AddXY(0, SignalPlotData.resultdata[6]);    // Surface 1
                            chartSignal.Series[2].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[6]);
                            chartSignal.Series[3].Points.AddXY(0, SignalPlotData.resultdata[7]);    // Surface 2
                            chartSignal.Series[3].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[7]);
                            chartSignal.Series[4].Points.AddXY(0, SignalPlotData.resultdata[8]);    // Surface 3
                            chartSignal.Series[4].Points.AddXY(SignalPlotData.tiltingdata_x[SignalPlotData.tiltingdata_x.Length - 1], SignalPlotData.resultdata[8]);
                            chartSignal.Series[5].Points.AddXY(SignalPlotData.resultdata[9], 0);    // Slope 1
                            chartSignal.Series[5].Points.AddXY(SignalPlotData.resultdata[9], SignalPlotData.tiltingdata_y.Max());
                            chartSignal.Series[6].Points.AddXY(SignalPlotData.resultdata[10], 0);   // Slope 2
                            chartSignal.Series[6].Points.AddXY(SignalPlotData.resultdata[10], SignalPlotData.tiltingdata_y.Max());
                            chartSignal.Series[7].Points.AddXY(SignalPlotData.resultdata[11], 0);   // Slope 3
                            chartSignal.Series[7].Points.AddXY(SignalPlotData.resultdata[11], SignalPlotData.tiltingdata_y.Max());
                        }

                        #endregion Plot

                        if (SignalPlotData.resultdata != null)
                        {
                            if (Wafertype == 1)
                            {
                                tb_result_0.Text = SignalPlotData.resultdata[0].ToString("f1") + fram.Analysis.Offset1StepH;
                                tb_result_1.Text = "0";
                                tb_result_2.Text = SignalPlotData.resultdata[1].ToString("f1") + fram.Analysis.Offset1StepW;
                                tb_result_3.Text = "0";
                            }
                            else
                            {
                                tb_result_0.Text = SignalPlotData.resultdata[0].ToString("f1") + fram.Analysis.Offset2StepH1;
                                tb_result_1.Text = (SignalPlotData.resultdata[2] + SignalPlotData.resultdata[0]).ToString("f1") + fram.Analysis.Offset2StepH2;
                                tb_result_2.Text = (SignalPlotData.resultdata[1] + SignalPlotData.resultdata[3]).ToString("f1") + fram.Analysis.Offset2StepW1;
                                tb_result_3.Text = SignalPlotData.resultdata[3].ToString("f1") + fram.Analysis.Offset2StepW2;
                            }
                        }
                    }

                    #endregion showtextbox

                    if (Wafertype != 0)
                        ParamFile.SaveRawdata_png(chartSignal, lb_analysisFileName.Text, DateTime.Now);

                    #region datagridview

                    string[] tmp = new string[5];
                    if (Wafertype == 1)
                    {
                        tmp[0] = SignalPlotData.resultdata[0].ToString("f1") + fram.Analysis.Offset1StepH;                                       //H1
                        tmp[1] = (SignalPlotData.resultdata[1] + SignalPlotData.resultdata[3]).ToString("f1") + fram.Analysis.Offset1StepW;     //W1
                        tmp[2] = (SignalPlotData.resultdata[2] + SignalPlotData.resultdata[0]).ToString("f1");       //H2
                        tmp[3] = SignalPlotData.resultdata[3].ToString("f1");                                       //W2
                    }
                    else if (Wafertype == 2)
                    {
                        tmp[0] = SignalPlotData.resultdata[0].ToString("f1") + fram.Analysis.Offset2StepH1;                                       //H1
                        tmp[1] = (SignalPlotData.resultdata[1] + SignalPlotData.resultdata[3]).ToString("f1") + fram.Analysis.Offset2StepW1;     //W1
                        tmp[2] = (SignalPlotData.resultdata[2] + SignalPlotData.resultdata[0]).ToString("f1") + fram.Analysis.Offset2StepH2;       //H2
                        tmp[3] = SignalPlotData.resultdata[3].ToString("f1") + fram.Analysis.Offset2StepW2;                                       //W2
                    }
                    else
                    {
                        tmp[0] = "0";   //H1
                        tmp[1] = SignalPlotData.resultdata[0].ToString("f2") + fram.Analysis.OffsetBlueTapeW;
                        tmp[2] = "0";   //H2
                        tmp[3] = "0";   //W2
                    }
                    if (Wafertype != 0)
                    {
                        if (SignalPlotData.resultdata[12] == 0)
                        {
                            tmp[4] = _filename;                                                          //Note
                        }
                        if (SignalPlotData.resultdata[12] == 1)
                        {
                            tmp[4] = _filename + " Chipping";                                                          //Note
                        }
                        dataGridView1.Rows.Add(tmp);
                    }

                    #endregion datagridview

                    progressBar_SignalAnalysis.Value = 100;
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                    Console.WriteLine(ee.Message);
                    progressBar_SignalAnalysis.Value = 100;
                }
            }
            else if (e.ProgressPercentage == 10)
            {
                MessageBox.Show(errormsg);
                //MessageBox.Show("分析錯誤，請重新選擇檔案及確認參數");
            }
        }

        private void btn_ClearDatagridview_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void cb_WaferType_SelectedIndexChanged(object sender, EventArgs e)
        {
            Wafertype = cb_WaferType.SelectedIndex;
            if (Wafertype == 0)
            {
                tabControl1.SelectedIndex = 1;
            }
            else
            {
                tabControl1.SelectedIndex = 0;
            }
        }
    }
}